import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/account/profile.dart';
import 'package:xavier_fyp/view/login.dart';

enum genderGroup { male, female, other }

class Infoacc extends StatefulWidget {
  const Infoacc({super.key});

  @override
  State<Infoacc> createState() => _InfoaccState();
}

class _InfoaccState extends State<Infoacc> {
  genderGroup _ma = genderGroup.male;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildAppBarAcc(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: SizedBox(
                height: 230,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  child: Column(
                    children: [
                      const CircleAvatar(
                        radius: 70,
                        backgroundImage: AssetImage('assets/obaid.png'),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Obaidullah Mansoor",
                        style: GoogleFonts.raleway(fontSize: 20),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "bcsm-s20-006@superior.edu.pk",
                        style: GoogleFonts.raleway(fontSize: 15),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: SizedBox(
                height: 478,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Column(
                      children: [
                        Text(
                          "Name",
                          style: GoogleFonts.raleway(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10,),
                        const TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            hintText: "Obaidullah Mansoor",
                            counterText: '',
                            enabled: false,
                          ),
                          keyboardType: TextInputType.name,
                          maxLength: 70,
                        ),
                        Text(
                          "Email",
                          style: GoogleFonts.raleway(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        const TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            hintText: "bcsm-s20-006@superior.edu.pk",
                            counterText: '',
                            enabled: false,
                          ),
                          keyboardType: TextInputType.emailAddress,
                          maxLength: 70,
                        ),
                        Text(
                          "Phone",
                          style: GoogleFonts.raleway(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        const TextField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            hintText: "+249048329483294",
                            counterText: '',
                            enabled: false,
                          ),
                          keyboardType: TextInputType.phone,
                          maxLength: 70,
                        ),
                        Text(
                          "Gender",
                          style: GoogleFonts.raleway(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ),
                        RadioListTile(
                          value: genderGroup.male,
                          title: Text("Male", style: GoogleFonts.poppins(fontSize: 15)),
                          groupValue: _ma,
                          onChanged: (genderGroup? val) {
                            print(val);
                            setState(() {
                              _ma = val!;
                            });
                          },
                        ),
                        RadioListTile(
                          value: genderGroup.female,
                          title: Text("Female", style: GoogleFonts.poppins(fontSize: 15)),
                          groupValue: _ma,
                          onChanged: (genderGroup? val) {
                            print(val);
                            setState(() {
                              _ma = val!;
                            });
                          },
                        ),
                        RadioListTile(
                          value: genderGroup.other,
                          title: Text("Other", style: GoogleFonts.poppins(fontSize: 15)),
                          groupValue: _ma,
                          onChanged: (genderGroup? val) {
                            print(val);
                            setState(() {
                              _ma = val!;
                            });
                          },
                        ),
                        SizedBox(
                            height: 30,
                            width: 300,
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => Profile()));
                              },
                              child: Text(
                                "Save",
                                style: GoogleFonts.openSans(
                                    fontWeight: FontWeight.bold, fontSize: 20),
                              ),
                            )),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  AppBar buildAppBarAcc() {
    return AppBar(
      elevation: 0,
      leading: IconButton(
        icon: SvgPicture.asset(
          "assets/icons/back.svg",
          color: Colors.white,
        ),
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => const Profile()));
        },
      ),
      title: Padding(
        padding: const EdgeInsets.only(left: 50.0),
        child: Text(
          "Account",
          style: GoogleFonts.poppins(fontSize: 25, color: Colors.white),
        ),
      ),
    );
  }
}

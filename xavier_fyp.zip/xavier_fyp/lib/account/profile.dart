import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/account/accountinfo.dart';
import 'package:xavier_fyp/view/homescreen.dart';
import 'package:xavier_fyp/view/login.dart';
import 'package:xavier_fyp/view/orderhistory.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   elevation: 0,
      //   leading: IconButton(
      //     icon: SvgPicture.asset(
      //       "assets/icons/back.svg",
      //       color: Colors.white,
      //     ),
      //     onPressed: () {
      //       Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
      //     },
      //   ),
      //   title: Padding(
      //     padding: const EdgeInsets.only(left: 35.0),
      //     child: Text(
      //       "My Profile",
      //       style: GoogleFonts.poppins(fontSize: 30, color: Colors.white),
      //     ),
      //   ),
      // ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: SizedBox(
                height: 240,
                width: MediaQuery.of(context).size.width,
                child: Card(
                  child: Column(
                    children: [
                      Padding(padding: EdgeInsets.only(top: 10.0)),
                      CircleAvatar(
                          radius: 70,
                          backgroundImage: AssetImage('assets/obaid.png'),
                        ),

                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Obaidullah Mansoor",
                        style: GoogleFonts.raleway(fontSize: 20),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "bcsm-s20-006@superior.edu.pk",
                        style: GoogleFonts.raleway(fontSize: 15),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Infoacc()));
                },
                child: SizedBox(
                  height: 65,
                  child: Card(
                    child: Row(
                      children: [
                        Padding(padding: EdgeInsets.only(left: 8.0)),
                        Icon(Icons.person),
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: Text(
                            "Edit Profile",
                            style: GoogleFonts.openSans(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(padding: EdgeInsets.only(left: 143)),
                        const Icon(
                          Icons.navigate_next,
                          color: Colors.black,
                          size: 25,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: GestureDetector(
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>OrderHist()));
                },
                child: SizedBox(
                  height: 65,
                  child: Card(
                    child: Row(
                      children: [
                        Padding(padding: EdgeInsets.only(left: 8.0)),
                        Icon(Icons.event_note_sharp),
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: Text(
                            "Order History",
                            style: GoogleFonts.openSans(
                                fontSize: 20, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(padding: EdgeInsets.only(left: 115)),
                        const Icon(
                          Icons.navigate_next,
                          color: Colors.black,
                          size: 25,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 50,
              width: 200,
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: ElevatedButton(

                onPressed: () {
                  showDialog(context: context, builder: (context){
                    return Container(
                      child: AlertDialog(
                        title: Text('Are You Sure?',style: GoogleFonts.openSans(fontWeight: FontWeight.bold),),
                        actions: [
                          TextButton(onPressed: (){
                            Navigator.pop(context);
                          }, child: Text('No',style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.bold),)),
                          TextButton(onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()));
                          }, child: Text('Yes',style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.bold),)),
                        ],
                      ),
                    );
                  });
                },
                child: Text(
                  'Signout',
                  style: GoogleFonts.openSans(
                      fontWeight: FontWeight.bold, fontSize: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


}

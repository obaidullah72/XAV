class Service {
  String imageUrl, titlename, descriptiont;
  int pricetag, id;

  Service(this.id, this.imageUrl, this.titlename, this.descriptiont, this.pricetag);

  static List<Service> listofservice = [
    Service(
      1,
      "assets/electric.png",
      "Electrician",
      "Great Service",
      234,
    ),
    Service(
      2,
      "assets/electric.png",
      "Electrician",
      "Great Service",
      234,
    ),
    Service(
      3,
      "assets/electric.png",
      "Electrician",
      "Great Service",
      234,
    ),

  ];
}

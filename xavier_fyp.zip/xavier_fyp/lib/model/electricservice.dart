class EService {
  String imageUrl, titlename, pricefrom;
  int id,pricetag;

  EService(this.id, this.imageUrl, this.titlename, this.pricefrom, this.pricetag);

  static List<EService> listofservice = [
    EService(
      1,
      "assets/electric.png",
      "Electrician",
      "from",
      45
    ),
    EService(
      2,
      "assets/plumber.png",
      "Plumber",
      "from",
      56
    ),
  ];
}

class Imgbody{
  String imgUrl;
  Imgbody(
      this.imgUrl
      );
  static List<Imgbody> listofimg =[
    Imgbody('assets/electric.png'),
    Imgbody('assets/fav.png'),
    Imgbody('assets/obaid.png'),
    Imgbody('assets/plumber.png'),
    Imgbody('assets/wiring.png'),
    Imgbody('assets/electric.png'),
  ];


}
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:xavier_fyp/account/profile.dart';
import 'package:xavier_fyp/view/favourite.dart';
import 'package:xavier_fyp/view/homescreen.dart';
import 'package:xavier_fyp/view/login.dart';
import 'package:xavier_fyp/view/orderhistory.dart';
import 'package:xavier_fyp/view/splashscreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Xavier',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Splashscr(),
    );
  }
}


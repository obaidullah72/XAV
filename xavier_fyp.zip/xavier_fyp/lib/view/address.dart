import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/account/profile.dart';
import 'package:xavier_fyp/view/addtocart.dart';
import 'package:xavier_fyp/view/checkout.dart';
import 'package:xavier_fyp/view/login.dart';

class Address extends StatefulWidget {
  const Address({super.key});

  @override
  State<Address> createState() => _AddressState();
}

class _AddressState extends State<Address> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: SvgPicture.asset(
            "assets/icons/back.svg",
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => const Checkout()));
          },
        ),
        title: Padding(
          padding: const EdgeInsets.only(left: 50.0),
          child: Text(
            "Address",
            style: GoogleFonts.poppins(fontSize: 25, color: Colors.white),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Container(
                height: MediaQuery.of(context).size.height,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Text(
                            "House",
                            style: GoogleFonts.raleway(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        //SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            hintText: "House No.",
                            counterText: '',
                            //enabled: false,
                          ),
                          keyboardType: TextInputType.name,
                          maxLength: 70,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Text(
                            "Street No",
                            style: GoogleFonts.raleway(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        //SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                BorderRadius.all(Radius.circular(10.0))),
                            hintText: "Street No.",
                            counterText: '',
                            //enabled: false,
                          ),
                          keyboardType: TextInputType.name,
                          maxLength: 70,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Text(
                            "Area",
                            style: GoogleFonts.raleway(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        //SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                BorderRadius.all(Radius.circular(10.0))),
                            hintText: "Area",
                            counterText: '',
                            //enabled: false,
                          ),
                          keyboardType: TextInputType.name,
                          maxLength: 70,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 10.0),
                          child: Text(
                            "City",
                            style: GoogleFonts.raleway(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        //SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                                borderRadius:
                                BorderRadius.all(Radius.circular(10.0))),
                            hintText: "City",
                            counterText: '',
                            //enabled: false,
                          ),
                          keyboardType: TextInputType.name,
                          maxLength: 70,
                        ),

                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 15.0),
                          child: SizedBox(
                              height: 45,
                              width: 200,
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => Checkout()));
                                },
                                child: Text(
                                  "Save",
                                  style: GoogleFonts.openSans(
                                      fontWeight: FontWeight.bold, fontSize: 20),
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

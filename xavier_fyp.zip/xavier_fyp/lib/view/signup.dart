import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:passwordfield/passwordfield.dart';
import 'package:xavier_fyp/view/homescreen.dart';
import 'package:xavier_fyp/view/login.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {

  bool obscure = true;
  var _isObscured;
  final passwordFocusNode = FocusNode();
  final passwordController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();

  void initState() {
    super.initState();
    _isObscured = true;
  }

  void dispose() {
    super.dispose();
    passwordController.dispose();
  }

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Container(
                height: 230,
                width: MediaQuery.of(context).size.width,
                color: HexColor('#018ae6'),
                // decoration: BoxDecoration(
                //   border: Border.all(
                //       color: Colors.black, width: 5.0, style: BorderStyle.solid),
                //   borderRadius: BorderRadius.circular(20),
                // ),

                child: Padding(
                  padding: const EdgeInsets.only(top: 75.0),
                  child: Column(
                    children: [
                      Text(
                        "Welcome\nBack",
                        style: GoogleFonts.raleway(
                            fontSize: 50,
                            fontWeight: FontWeight.bold,
                            color: Colors.white),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Container(
                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  color: Colors.white,
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 10.0, bottom: 5.0),
                        child: Text(
                          "SignUp",
                          style: GoogleFonts.openSans(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 1,138,230),),
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              "Name",
                              style: GoogleFonts.raleway(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: SizedBox(
                          height: 90.0,
                          width: width - 30,
                          child: TextFormField(
                            controller: nameController,
                            //onSaved: (input) => loginRequestModel.email = input!,
                            cursorColor: Colors.white,
                            keyboardType: TextInputType.name,
                            decoration: InputDecoration(
                              labelText: 'Name',
                              labelStyle: const TextStyle(
                                  color: Colors.grey, fontSize: 18),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 1, 138, 230),
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 1, 138, 230),
                                ),
                              ),
                              contentPadding:
                              const EdgeInsets.symmetric(vertical: 20),
                              prefixIcon: const Icon(
                                Icons.person,
                                color: Color.fromARGB(255, 1, 138, 230),
                              ),
                              filled: true,
                              fillColor: const Color(0xffF2F2F3),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                            style: const TextStyle(color: Colors.black),

                            //the validator receive the text that the user has entered
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "please enter some text";
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              "Email",
                              style: GoogleFonts.raleway(
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: SizedBox(
                          height: 90.0,
                          width: width - 30,
                          child: TextFormField(
                            controller: emailController,
                            //onSaved: (input) => loginRequestModel.email = input!,
                            cursorColor: Colors.white,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              labelText: 'Email',
                              labelStyle: const TextStyle(
                                  color: Colors.grey, fontSize: 18),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 1, 138, 230),
                                ),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: const BorderSide(
                                  color: Color.fromARGB(255, 1, 138, 230),
                                ),
                              ),
                              contentPadding:
                              const EdgeInsets.symmetric(vertical: 20),
                              prefixIcon: const Icon(
                                Icons.email,
                                color: Color.fromARGB(255, 1, 138, 230),
                              ),
                              filled: true,
                              fillColor: const Color(0xffF2F2F3),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20.0),
                              ),
                            ),
                            style: const TextStyle(color: Colors.black),

                            //the validator receive the text that the user has entered
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return "please enter some text";
                              }
                              return null;
                            },
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 8.0),
                            child: Text(
                              "Password",
                              style: GoogleFonts.raleway(
                                  fontWeight: FontWeight.bold, fontSize: 15, ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        obscureText: _isObscured,
                        focusNode: passwordFocusNode,
                        keyboardType: TextInputType.emailAddress,
                        controller: passwordController,
                        decoration: InputDecoration(
                            labelText: 'Password',
                            labelStyle: const TextStyle(
                              color: Colors.grey,
                              fontSize: 18,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: Color.fromARGB(255, 1, 138, 230),
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: const BorderSide(
                                color: Color.fromARGB(255, 1, 138, 230),
                              ),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 25.0),
                            prefixIcon: const Icon(
                              Icons.lock_open,
                              color: Color.fromARGB(255, 1, 138, 230),
                              size: 28,
                            ),
                            filled: true,
                            suffixIcon: GestureDetector(
                              onTap: () {
                                setState(() {
                                  _isObscured = !_isObscured;
                                });
                              },
                              child: Icon(
                                _isObscured
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Color.fromARGB(255, 1,138,230),
                              ),
                            ),
                            //Icon(Icons.remove_red_eye,color: Color(0xffFCDA17),),
                            fillColor: const Color(0xffF2F2F3),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20.0),
                              //gapPadding: 5.0,
                            )),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            passwordFocusNode.requestFocus();
                            return 'Please Enter Some Text';
                          }
                          if (value.length < 6) {
                            passwordFocusNode.requestFocus();
                            return 'Password must be at least 6 characters';
                          }
                        },
                      ),
                      const SizedBox(height: 10),
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: SizedBox(
                          height: 50,
                          width: 300,
                          child: ElevatedButton(
                            clipBehavior: Clip.hardEdge,
                            onPressed: () {
                              FirebaseAuth.instance
                                  .createUserWithEmailAndPassword(
                                      email: emailController.text,
                                      password: passwordController.text)
                                  .then((value) => {
                                        print("Created New Account"),
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const LoginPage()))
                                      })
                                  .onError((error, stackTrace) =>
                                      {print("Error ${error.toString()}")});
                            },
                            style: ElevatedButton.styleFrom(
                                shape: new RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                backgroundColor: Colors.blue),
                            //                       onHover: AnimatedOpacity,
                            child: const Text(
                              'SignUp',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 46.0),
                        child: Row(
                          children: [
                            Text('Already have an account?',
                                style: TextStyle(fontSize: 15)),
                            TextButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const LoginPage()),
                                );
                              },
                              child: const Text("Login",
                                  style: TextStyle(fontSize: 16)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

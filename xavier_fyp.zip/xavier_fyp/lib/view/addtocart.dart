import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/view/homescreen.dart';


enum COD {cod}
class AddCart extends StatefulWidget {
  const AddCart({
    Key? key,
  }) : super(key: key);

  @override
  _AddCartState createState() => _AddCartState();
}

class _AddCartState extends State<AddCart> {
  COD _cod = COD.cod;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back), color: Colors.white, onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => HomeScreen()));
        },),
        title: Text(
          "Cart",
          style:
          GoogleFonts.openSans(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Container(
                clipBehavior: Clip.hardEdge,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        child: Image.asset('assets/electric.png'),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    'Wiriing',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: HexColor('#018ae6'),
                                      fontWeight: FontWeight.w500,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                IconButton(
                                    splashRadius: 20,
                                    onPressed: () {
                                    },
                                    icon: const Icon(
                                      Icons.delete_outline_sharp,
                                      color: Colors.grey,
                                    )),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '65',
                                  //'${cartItem.price * cartItem.quantity}\$',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: HexColor('#018ae6')),
                                ),
                                // Row(
                                //   children: [
                                //     IconButton(
                                //       onPressed: () {
                                //         // provider
                                //         //     .decreaseQuantityCart(cartItem.productId);
                                //       },
                                //       splashRadius: 20,
                                //       icon: const Icon(
                                //         Icons.remove,
                                //         size: 18,
                                //         color: Colors.grey,
                                //       ),
                                //     ),
                                //     Text(
                                //       '',
                                //       //cartItem.quantity.toInt().toString(),
                                //       style: TextStyle(
                                //           color: HexColor('#018ae6'),
                                //           fontWeight: FontWeight.bold,
                                //           fontSize: 16),
                                //     ),
                                //     IconButton(
                                //       onPressed: () {
                                //         // provider
                                //         //     .increaseQuantityCart(cartItem.productId);
                                //       },
                                //       splashRadius: 20,
                                //       icon: const Icon(
                                //         Icons.add,
                                //         size: 18,
                                //         color: Colors.grey,
                                //       ),
                                //     ),
                                //   ],
                                // ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Row(
                children: [
                  Text(
                    "Payment Method",
                    style: GoogleFonts.raleway(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Card(
                child: RadioListTile(
                  value: COD.cod,
                  groupValue: _cod,
                  title: Text(
                    "Cash On Delivery (COD)",
                    style: GoogleFonts.openSans(
                        fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  onChanged: (value) {
                    setState(
                          () {
                        _cod = value!;
                      },
                    );
                  },
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              height: 50,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  Text(
                    "Total",
                    style: GoogleFonts.raleway(
                        fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 230.0),
                    child: Text(
                      "139",
                      style: GoogleFonts.raleway(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: HexColor("#018AE6")),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 50,
              width: 150,
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
              ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  primary: HexColor("#018AE6"),
                ),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
                },
                child: Text(
                  "Checkout",
                  style: GoogleFonts.raleway(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

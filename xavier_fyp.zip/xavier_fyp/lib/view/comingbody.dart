import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:xavier_fyp/view/categorieshome.dart';

class BodyComing extends StatelessWidget {
  const BodyComing({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 40.0),
          child: Column(
            children: [
              Text(
                "Welcome To",
                style: Theme.of(context).textTheme.headline2,
              ),
              Text(
                "Xavier",
                style: Theme.of(context).textTheme.headline2,
              ),
            ],
          ),
        ),
        const Categories(),
        Column(
          children: [
            Image.asset('assets/comingsoon.png'),
            Text(
              "Coming Soon",
              style: GoogleFonts.poppins(fontSize: 40.0),
            ),
          ],
        ),
      ],
    );
  }
}

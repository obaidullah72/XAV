import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/view/homescreen.dart';

class Favorder extends StatelessWidget {
  const Favorder({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: SvgPicture.asset(
            "assets/icons/back.svg",
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => const HomeScreen()));
          },
        ),
        title: Text(
            "Favourites",
            style: GoogleFonts.poppins(fontSize: 25, color: Colors.white),
          ),
      ),
        body: Column(
          children: [
            const SizedBox(
              height: 20,
            ),
            Image.asset('assets/fav.png'),
            const SizedBox(
              height: 20,
            ),
            Text(
              "No favourite yet",
              style: GoogleFonts.raleway(
                  fontWeight: FontWeight.bold, fontSize: 30),
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              "Hit the orange button down",
              style: GoogleFonts.raleway(
                  fontSize: 20),
            ),
            Text(
              "below to Create an order",
              style: GoogleFonts.raleway(
                  fontSize: 20),
            ),
            const SizedBox(
              height: 30,
            ),
            SizedBox(
              height: 50,
              width: 300,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>HomeScreen()));
                },
                child: Text(
                  "Start Ordering",
                  style: GoogleFonts.raleway(
                      fontWeight: FontWeight.bold, fontSize: 30),
                ),
              ),
            ),
          ],
        ),
      );
  }

}

import 'package:carousel_slider/carousel_slider.dart';

//import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/model/electricservice.dart';
import 'package:xavier_fyp/view/itembody.dart';
import 'package:xavier_fyp/view/login.dart';

import '../constants.dart';
import 'electricprod.dart';

class ItemDes extends StatefulWidget {
  const ItemDes({super.key});

  @override
  State<ItemDes> createState() => _ItemDesState();
}

class _ItemDesState extends State<ItemDes> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: IconButton(
          icon: SvgPicture.asset(
            "assets/icons/back.svg",
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (context) => ElectricProduct()));
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: SvgPicture.asset(
              "assets/icons/favourite.svg",
              color: Colors.white,
            ),
            onPressed: () {},
          ),
          const SizedBox(width: kDefaultPaddin / 2)
        ],
      ));
      // body: SingleChildScrollView(
      //   child: ItemBody(),
      //     // child: ListView.builder(itemBuilder: (context, index) {
      //     //   return Card(child: eService: EService.listofservice[index]);
      //     // }
      // ));
  }
}

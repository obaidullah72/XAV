import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/view/homescreen.dart';
import 'package:xavier_fyp/view/signup.dart';

import '../Error/formerror.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  final List<String?> errors = [];

  void addError({String? error}) {
    if (!errors.contains(error))
      setState(() {
        errors.add(error);
      });
  }

  void removeError({String? error}) {
    if (errors.contains(error))
      setState(() {
        errors.remove(error);
      });
  }




  late String email;
  late String password;
  bool showSpinner = false;
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool submit = true;
  bool obscure = true;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Container(
          height: height,
          width: width,
          decoration: const BoxDecoration(color: Color(0xffF2F2F3)),
          child: SingleChildScrollView(
              child: Form(
            key: _formKey,
            child: Column(
                //all of the login widgets would be here
                children: [
                  //first container consisting of logo
                  // SizedBox(
                  //   width: 300,
                  //   height: 300,
                  //   child: Image.asset('assets/imag/maahey-logo.png'),
                  // ),
                  Container(
                    height: 275,
                    width: MediaQuery.of(context).size.width,
                    color: HexColor('#018ae6'),
                    // decoration: BoxDecoration(
                    //   border: Border.all(
                    //       color: Colors.black, width: 5.0, style: BorderStyle.solid),
                    //   borderRadius: BorderRadius.circular(20),
                    // ),

                    child: Padding(
                      padding: const EdgeInsets.only(top: 125.0),
                      child: Column(
                        children: [
                          Text(
                            "Welcome\nBack",
                            style: GoogleFonts.raleway(
                                fontSize: 50,
                                fontWeight: FontWeight.bold,
                                color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),

                  //login text
                  //email field
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0),
                    child: Container(
                      height: MediaQuery.of(context).size.height,
                      child: Column(
                        children: [
                          Padding(
                            padding:
                                const EdgeInsets.only(top: 10.0, bottom: 5.0),
                            child: Text(
                              "Login",
                              style: GoogleFonts.openSans(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 1,138,230),),
                            ),
                          ),
                          Row(
                            children: [
                              //Icon(Icons.email,color: Color.fromARGB(255, 1,138,230),),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: Text(
                                  "Email",
                                  style: GoogleFonts.raleway(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 15),
                            child: SizedBox(
                              height: 90.0,
                              width: width - 30,
                              child: TextFormField(
                                controller: emailController,
                                //onSaved: (input) => loginRequestModel.email = input!,
                                cursorColor: Colors.white,
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                  labelText: 'Email',
                                  labelStyle: const TextStyle(
                                      color: Colors.grey, fontSize: 18),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 1, 138, 230),
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20),
                                    borderSide: const BorderSide(
                                      color: Color.fromARGB(255, 1, 138, 230),
                                    ),
                                  ),
                                  contentPadding:
                                      const EdgeInsets.symmetric(vertical: 20),
                                  prefixIcon: const Icon(
                                    Icons.email,
                                    color: Color.fromARGB(255, 1, 138, 230),
                                  ),
                                  filled: true,
                                  fillColor: const Color(0xffF2F2F3),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),
                                style: const TextStyle(color: Colors.black),

                                //the validator receive the text that the user has entered
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return "please enter some text";
                                  }
                                  return null;
                                },
                                onSaved: (value){
                                  email = value!;
                                },
                              ),
                            ),
                          ),
                          Row(
                            children: [
                              // Icon(
                              //   Icons.lock_open,
                              //   color: Color.fromARGB(255, 1, 138, 230),
                              // ),
                              Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                child: Text(
                                  "Password",
                                  style: GoogleFonts.raleway(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 15),
                                ),
                              ),
                            ],
                          ),
                          //password field
                          Padding(
                            padding: const EdgeInsets.only(top: 15),
                            child: SizedBox(
                              height: 90,
                              width: width - 30,
                              child: TextFormField(
                                controller: passwordController,
                                //onSaved: (input) => loginRequestModel.password = input!,

                                cursorColor: Color.fromARGB(255, 1, 138, 230),
                                obscureText: obscure,
                                enableSuggestions: false,
                                autocorrect: false,
                                decoration: InputDecoration(
                                    labelText: 'Password',
                                    labelStyle: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 18,
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: const BorderSide(
                                        color: Color.fromARGB(255, 1, 138, 230),
                                      ),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20),
                                      borderSide: const BorderSide(
                                        color: Color.fromARGB(255, 1, 138, 230),
                                      ),
                                    ),
                                    contentPadding: const EdgeInsets.symmetric(
                                        vertical: 25.0),
                                    prefixIcon: const Icon(
                                      Icons.lock_open,
                                      color: Color.fromARGB(255, 1, 138, 230),
                                      size: 28,
                                    ),
                                    filled: true,
                                    suffixIcon: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          obscure = !obscure;
                                        });
                                      },
                                      child: Icon(
                                        obscure
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                        color: Color.fromARGB(255, 1,138,230),
                                      ),
                                    ),
                                    //Icon(Icons.remove_red_eye,color: Color(0xffFCDA17),),
                                    fillColor: const Color(0xffF2F2F3),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(20.0),
                                      //gapPadding: 5.0,
                                    )),
                                style: const TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'productsan'),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'please enter some text';
                                  } else if (value.length < 6) {
                                    return 'password length at least 6(characters and alphabets)';
                                  }
                                  return null;
                                },
                              ),
                            ),
                          ),

                          //remeber me + forgot password
                          TextButton(
                            onPressed: () {
                              showModalBottomSheet<void>(
                                context: context,
                                builder: (BuildContext context) {
                                  return Container(
                                    clipBehavior: Clip.hardEdge,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                          topRight: Radius.circular(20),
                                          topLeft: Radius.circular(20)),
                                      color: Colors.white,
                                    ),
                                    height: 350,
                                    child: Center(
                                      child: Column(
                                        // mainAxisAlignment: MainAxisAlignment.center,
                                        // mainAxisSize: MainAxisSize.min,
                                        children: <Widget>[
                                          Image.asset(
                                            'assets/bar.png',
                                            height: 30,
                                          ),
                                          Text(
                                            'Reset Password?',
                                            style: GoogleFonts.openSans(
                                                fontSize: 28,
                                                fontWeight: FontWeight.bold),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            'Enter the email address\nassociated your account',
                                            style: GoogleFonts.openSans(
                                                fontSize: 18),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                                horizontal: 15.0),
                                            child: TextFormField(
                                              decoration: InputDecoration(
                                                border: OutlineInputBorder(
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                12.0))),
                                                hintText: "Email address",
                                                labelText: 'Email',
                                                counterText: '',
                                              ),
                                              keyboardType:
                                                  TextInputType.emailAddress,
                                              maxLength: 70,
                                            ),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          ElevatedButton(
                                            child: const Text('Reset Password'),
                                            onPressed: () {},
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              );
                            },
                            child: const Text("Forgot Passcode?",
                                style: TextStyle(fontSize: 15)),
                          ),

                          //login button
                          FormError(errors: errors),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                                  const Color.fromARGB(255, 1, 138, 230),
                              minimumSize: const Size(200, 50),
                              maximumSize: const Size(200, 50),
                            ),
                            onPressed: () {
                              FirebaseAuth.instance
                                  .signInWithEmailAndPassword(
                                      email: emailController.text,
                                      password: passwordController.text)
                                  .then((value) => {
                                        print("Login Successful"),
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const HomeScreen()))
                                      })
                                  .onError((error, stackTrace) =>
                                      {print("Error ${error.toString()}")});
                            },
                            child: const Text(
                              'Login',
                              style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),

                          const Padding(padding: EdgeInsets.only(top: 20)),
                          //not registered clickable text
                          SizedBox(
                            height: 20,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => const Signup()));
                              },
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Text(
                                    'Not registered yet? ',
                                    style: TextStyle(color: Color(0xff424242)),
                                  ),
                                  Text(
                                    'Create an Account?',
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 1, 138, 230),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ], //closing of child widgets
                      ),
                    ),
                  ),
                ]),
          ))),
    );
  }

  bool validateAndSave() {
    final form = _formKey.currentState;
    if (form!.validate()) {
      form.save();
      return true;
    }
    return false;
  }
}

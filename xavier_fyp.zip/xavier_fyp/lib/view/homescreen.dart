import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:xavier_fyp/account/profile.dart';
import 'package:xavier_fyp/view/addtocart.dart';
import 'package:xavier_fyp/view/favourite.dart';
import 'package:xavier_fyp/view/homebody.dart';
import 'package:xavier_fyp/view/login.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedindex = 0;
  bool tappedYes = false;

  static List<Widget> pages = <Widget>[
    const BodyHome(),
    const Favorder(),
    const AddCart(),
    const Profile(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedindex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: HexColor('#018ae6'),
        title: Padding(
          padding: const EdgeInsets.only(left: 50.0),
          child: Text('XAVIER', style: GoogleFonts.openSans(fontSize: 40),),
        ),
      ),
      body: pages[_selectedindex],
      drawer: Drawer(
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              decoration: BoxDecoration(color: HexColor('#018ae6')),
              accountName: Text(
                "Obaidullah Mansoor",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              accountEmail: Text(
                "bcsm-s20-006@superior.edu.pk",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              currentAccountPicture: FlutterLogo(),
            ),
            ListTile(
              leading: Icon(
                Icons.home,
              ),
              title: const Text('Home'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => HomeScreen()));
              },
            ),
            ListTile(
              leading: Icon(
                Icons.favorite,
              ),
              title: const Text('Favourite'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Favorder()));
              },
            ),
            ListTile(
              leading: Icon(
                Icons.person,
              ),
              title: const Text('Account'),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Profile()));
              },
            ),
            AboutListTile(
              // <-- SEE HERE
              icon: Icon(
                Icons.info,
              ),
              child: Text('About app'),
              applicationIcon: Icon(
                Icons.local_play,
              ),
              applicationName: 'Xavier',
              applicationVersion: '1.0.2',
              applicationLegalese: '© 2022 SuperHeroes',
              aboutBoxChildren: [
                ///Content goes here...
              ],
            ),
            ListTile(
              leading: Icon(
                Icons.exit_to_app,
              ),
              title: const Text('SignOut'),
              onTap: () {
                showDialog(context: context, builder: (context){
                  return Container(
                    child: AlertDialog(
                      title: Text('Are You Sure?',style: GoogleFonts.openSans(fontWeight: FontWeight.bold),),
                      actions: [
                        TextButton(onPressed: (){
                          Navigator.pop(context);
                        }, child: Text('No',style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.bold),)),
                        TextButton(onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=> LoginPage()));
                        }, child: Text('Yes',style: GoogleFonts.poppins(fontSize: 18,fontWeight: FontWeight.bold),)),
                      ],
                    ),
                  );
                });
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        // 5
        unselectedItemColor: Colors.grey,
        selectedItemColor: Colors.blue,
        currentIndex: _selectedindex,
        onTap: _onItemTapped,
        // 6
        items: <BottomNavigationBarItem>[
          new BottomNavigationBarItem(
            backgroundColor: Colors.white,
            icon: Icon(Icons.home),
            label: "Home",
          ),
          new BottomNavigationBarItem(
            icon: Icon(Icons.favorite),
            label: "Favourite",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.shopping_cart),
            label: "Cart",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Profile",
          ),
        ],
      ),
    );
  }

// AppBar buildAppBar() {
//   return AppBar(
//     backgroundColor: HexColor('#F6F6F9'),
//     elevation: 0,
//     );
// }
}

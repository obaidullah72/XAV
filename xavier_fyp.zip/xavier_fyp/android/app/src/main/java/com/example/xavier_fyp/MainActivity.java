package com.example.xavier_fyp;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
